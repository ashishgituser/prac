package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	private static XSSFRow Row;

	static String tcName;
	static String loginID;
	static String password;

//	Setter methods to set field values
	public static void setTCName(String stringCellValue) {
		tcName = stringCellValue;
	}

	public static void setPassword(String stringCellValue) {
		loginID = stringCellValue;
	}

	public static void setLogin(String stringCellValue) {
		password = stringCellValue;
	}

//	Getter methods to get field values
	public static String getTCName() {
		return tcName;
	}

	public static String getLoginID() {
		return loginID;
	}

	public static String getPassword() {
		return password;
	}

	public static XSSFWorkbook openExcel() throws IOException {
		File file_path = new File(PropertiesUtil.getPropertyValue("test_Data_path"));
		FileInputStream fis = new FileInputStream(file_path);
		XSSFWorkbook wb = new XSSFWorkbook(fis);

		if (!(file_path.isFile() && file_path.exists())) {
			throw new FileNotFoundException("Test data file is not found at: " + file_path);
		}
		return wb;
	}

	public static Object[][] getTableArray(String FilePath, String SheetName) throws Exception {

		String[][] tabArray = null;
		try {
			FileInputStream ExcelFile = new FileInputStream(FilePath);
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			int startRow = 1;
			int startCol = 1;
			int ci, cj;
			int totalRows = ExcelWSheet.getLastRowNum();
			int totalCols = 2;

			tabArray = new String[totalRows][totalCols];
			ci = 0;
			for (int i = startRow; i <= totalRows; i++, ci++) {
				cj = 0;
				for (int j = startCol; j <= totalCols; j++, cj++) {
					tabArray[ci][cj] = getCellData(i, j);
					System.out.println(tabArray[ci][cj]);
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		return (tabArray);
	}

	public static String getCellData(int RowNum, int ColNum) throws Exception {
		try {
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			String CellData = Cell.getStringCellValue();
			return CellData;
			//int dataType = Cell.getCellType();
			/*
			 * if (dataType == 3) { return ""; } else { String CellData =
			 * Cell.getStringCellValue(); return CellData; }
			 */
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw (e);

		}
	}

	public static void readSheet(String TC_name, XSSFWorkbook wb) throws IOException {
		XSSFRow row;
		XSSFSheet sh = wb.getSheetAt(0);
		XSSFCell cell;
		int tot_num_of_rows = sh.getPhysicalNumberOfRows();
		Iterator<Row> rowIterator = sh.iterator();

		for (int i = 0; i < tot_num_of_rows; i++) {
			row = (XSSFRow) rowIterator.next();
			int tot_num_of_cols = row.getPhysicalNumberOfCells();

			Iterator<Cell> cellIterator = row.cellIterator();
			cell = (XSSFCell) cellIterator.next();

			if (cell.getStringCellValue().equalsIgnoreCase(TC_name)) {
				setTCName(cell.getStringCellValue());

				for (int j = 1; j < tot_num_of_cols; j++) {
					cell = (XSSFCell) cellIterator.next();
					switch (j) {
					case 1:
						setLogin(cell.getStringCellValue());
						break;
					case 2:
						setPassword(cell.getStringCellValue());
						break;
					}
				}
				break;
			}
		}
	}
}
