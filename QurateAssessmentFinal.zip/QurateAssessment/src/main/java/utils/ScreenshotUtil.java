package utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenshotUtil {

	public static String capture(WebDriver driver, long screenshotTime) {
		TakesScreenshot ts = (TakesScreenshot) driver; // Interface: Indicates a driver that can capture a screenshot
														// and store it in different ways
		File sourceFile = ts.getScreenshotAs(OutputType.FILE);
		String screenshotPath = PropertiesUtil.getPropertyValue("screenshots") + screenshotTime + ".png";
		File destinationFile = new File(screenshotPath);
		try {
			FileUtils.copyFile(sourceFile, destinationFile);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return screenshotPath;
	}

}
