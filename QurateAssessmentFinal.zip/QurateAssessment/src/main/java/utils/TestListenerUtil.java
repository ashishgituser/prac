package utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import resources.Base;

public class TestListenerUtil implements ITestListener {

	private static final Logger log = LogManager.getLogger(Base.class.getName());
	Base b = new Base();

	public void onTestStart(ITestResult result) {
		log.info("onTestStart is executed");
	}

	public void onTestSuccess(ITestResult result) {
		log.info("onTestSuccess is executed");
	}

	public void onTestFailure(ITestResult result) {
		log.info("onTestFailure is executed");
	}

	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
	}

	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
	}

	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
	}

}
