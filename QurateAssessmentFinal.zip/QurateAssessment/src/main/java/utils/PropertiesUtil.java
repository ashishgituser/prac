package utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import resources.Base;

public class PropertiesUtil {

	private static String filePath;
	private static String propertyValue;
	private final static Logger log = LogManager.getLogger(Base.class.getName());

/*	public PropertiesUtil(String pathSpecifier) {
		if (pathSpecifier.equals("main")) {
			filePath = ".//src//main//resources//Object.properties";
			log.info("Using 'src/main/resources' Properties File.");
		} else if (pathSpecifier.equals("test")) {
			filePath = ".//src//test//resources//Object.properties";
			log.info("Using 'src/test/resources' Properties File.");
		} else {
			log.info("Cannot find the Properties file. Please specify the correct String : 'main' or 'test'.");
		}
	}*/

	public static String getPropertyValue(String key) {
		FileReader fr = null;
		try {
			fr = new FileReader(filePath);
			Properties prop = new Properties();
			prop.load(fr);
			propertyValue = prop.getProperty(key);
		} catch (FileNotFoundException e) {
			log.info("Property file is not found at specified path");
			e.printStackTrace();
		} catch (IOException e) {
			log.info("Provided key is not present in property file");
			e.printStackTrace();
		} finally {
			try {
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return propertyValue;
	}

}
