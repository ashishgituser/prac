package utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class CommonUtilExtra {

	public static void setDate(WebDriver driver, String date, String locator, ExtentTest test)
			throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("document.getElementById('').value='" + date + "'");

		test.log(Status.INFO, "Set date: " + date);
		Thread.sleep(1000);
		return;
	}

	public static void selectDropDown(WebElement element, String valueToSet, ExtentTest test)
			throws InterruptedException {
		Select dropDown = new Select(element);
		dropDown.selectByVisibleText(valueToSet);
		test.log(Status.INFO, "Set dropDown: " + valueToSet);
		Thread.sleep(1000);
	}

	public static void inputData(WebElement element, String valueToSet, ExtentTest test) throws InterruptedException {
		element.sendKeys(valueToSet);

		test.log(Status.INFO, "Set text: " + valueToSet);
		Thread.sleep(1000);
	}
}
