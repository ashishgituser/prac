package utils;

import java.io.IOException;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import resources.Base;

public class ReportsUtil extends Base {

	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest test;

	// BeforeTest
	public void startReport() {
		htmlReporter = new ExtentHtmlReporter(PropertiesUtil.getPropertyValue("reportPath"));
		extent = new ExtentReports(); // creates extent report object
		extent.attachReporter(htmlReporter); // attaches extent report to the html file

		// To Provide some extra information:

		extent.setSystemInfo("OS", "win10");
		extent.setSystemInfo("hostname", "dvgoel");

		htmlReporter.config().setDocumentTitle("Report");
		htmlReporter.config().setReportName("Qurate Test");
		htmlReporter.config().setTheme(Theme.DARK);
	}

	// AfterMethod

	public void getResult(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshotPath = ScreenshotUtil.capture(Base.initializeDriver(), System.currentTimeMillis());
			test.log(Status.FAIL, MarkupHelper.createLabel(result.getName(), ExtentColor.RED));
			test.fail(result.getThrowable());
			try {
				test.fail("Screenshot Below:" + test.addScreenCaptureFromPath(screenshotPath));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(Status.PASS, MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
		} else if (result.getStatus() == ITestResult.SKIP) {
			test.log(Status.SKIP, MarkupHelper.createLabel(result.getName(), ExtentColor.YELLOW));
			test.skip(result.getThrowable());
		}
	}

	// AfterTest
	public void testDown() {
		extent.flush();
	}

	@Test
	public static void demoTestPass() {
		test = extent.createTest("demoTestPass", "pass test demo");
		test.log(Status.INFO, "test string");
		// Using labels
		test.info(MarkupHelper.createLabel("test string", ExtentColor.BLUE));

		Assert.assertTrue(true);
	}

	@Test
	public static void demoTestFail() {
		test = extent.createTest("demoTestFail", "fail test demo");
		Assert.assertTrue(false);
	}

	@Test
	public static void DemoTestSkip() {
		test = extent.createTest("demoTestSkip", "skip test demo");

		throw new SkipException("skipping this test");
	}
}