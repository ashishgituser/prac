package com.amazon.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import resources.Base;

public class AmazonLandingPage extends Base {

	public WebDriver driver;

	public AmazonLandingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	By accountAndListsCTA = By.xpath("//*[@id='nav-link-accountList' and @data-nav-role='signin']");
	By signInCTA = By.xpath("//div[@id='nav-al-signin']//span[contains(.,'Sign in') and @class='nav-action-inner']");
	By startHereCTA = By.xpath("//div[@id='nav-al-signin']//a[contains(.,'Start here.')]");
	By shopByCategoryCTA = By.xpath("//a[@id='nav-link-shopall']");
	By searchBox = By.xpath("//input[@id='twotabsearchtextbox']");
	By parkAvenueText = By.xpath("//*[contains(text(),'Park Avenue Soap')]");
	By sellOnAmazon = By.xpath("//a[text()='Sell on Amazon']");
	By getToKnowUs = By.xpath("//div[@id='navFooter']//div[text()='Get to Know Us']");
	By image = By.xpath("//img[@class='s-image']");
	By addToCart = By.id("add-to-cart-button");
	By signInCTA1 = By.xpath("//div[@id='nav-al-signin']//span[contains(.,'Sign in') and @class='nav-action-inner']");
	By startHereCTA1 = By.xpath("//div[@id='nav-al-signin']//a[contains(.,'Start here.')]");
	By shopByCategoryCTA1 = By.xpath("//a[@id='nav-link-shopall']");


	/*
	 * public WebElement getAccountsAndListsCTA() { return
	 * driver.findElement(accountAndListsCTA); }
	 * 
	 * public WebElement getsignInCTA() { return driver.findElement(signInCTA); }
	 * 
	 * public WebElement getstartHereCTA() { return
	 * driver.findElement(startHereCTA); }
	 * 
	 * public WebElement getshopByCategoryCTA() { return
	 * driver.findElement(shopByCategoryCTA); }
	 * 
	 * public WebElement getSearchText() { return driver.findElement(searchText1); }
	 */

	public void enterSearchText(String text) {
		//sendKeys(searchBox, text);
		WebElement element = getElement(searchBox);
		element.click();
		sendKeys(searchBox,text);
		//element.sendKeys(Keys.ENTER);
	}

	public void pressEnter() {
		sendKeys(searchBox, Keys.ENTER);
	}

	public void scrollToSellOnAmazonAndClick() throws InterruptedException {
		scrollToThenClick(sellOnAmazon);
	}

	public void clickAddToCart() {
		click(addToCart);
	}

	public void hoverAccountsAndListsCTA() {
		hover(accountAndListsCTA);
	}

	public void clickSignInCTA() {
		click(signInCTA);
	}

}
