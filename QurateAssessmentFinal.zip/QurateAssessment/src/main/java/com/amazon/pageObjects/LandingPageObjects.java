package com.amazon.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandingPageObjects {

	public WebDriver driver;

	public LandingPageObjects(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='nav-link-accountList' and @data-nav-role='signin']")
	public WebElement accountAndListsCTA1;

	@FindBy(xpath = "//div[@id='nav-flyout-ya-signin']//span[contains(.,'Sign in')]")
	public WebElement signInCTA;

	@FindBy(xpath = "//input[@id='twotabsearchtextbox']")
	public WebElement searchBox;

	@FindBy(xpath = "//span[contains(.,'Park Avenue Soap Cool Blue, 125g (Pack of 6)')]")
	public WebElement searchText;

	@FindBy(xpath = "//img[@class='s-image']")
	public WebElement image;

	@FindBy(id = "add-to-cart-button")
	public WebElement addToCart;

	@FindBy(xpath = "//div[@id='nav-al-signin']//span[contains(.,'Sign in') and @class='nav-action-inner']")
	public WebElement signInCTA1;

	@FindBy(xpath = "//div[@id='nav-al-signin']//a[contains(.,'Start here.')]")
	public WebElement startHereCTA1;

	@FindBy(xpath = "//a[@id='nav-link-shopall']")
	public WebElement shopByCategoryCTA1;
	

}
