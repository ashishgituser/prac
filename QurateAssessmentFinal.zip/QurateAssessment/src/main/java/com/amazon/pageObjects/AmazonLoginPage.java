package com.amazon.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import resources.Base;

public class AmazonLoginPage extends Base{

	public WebDriver driver;

	public AmazonLoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	By userName = By.xpath("//input[@id='ap_email']");
	By continueCTA = By.xpath("//input[@id='continue']");
	By passWord = By.xpath("//input[@id='ap_password']");
	By loginCTA = By.xpath("//input[@id='signInSubmit']");

	public WebElement getUserName() {
		return driver.findElement(userName);
	}

	public WebElement getContinueCTA() {
		return driver.findElement(continueCTA);
	}

	public WebElement getPassWord() {
		return driver.findElement(passWord);
	}

	public WebElement getLoginCTA() {
		return driver.findElement(loginCTA);
	}

	public void enterUsername(String username) {
		waitForElementToBeVisible(userName);
		sendKeys(userName, username);
	}
	
	public void clickContinueButton() {
		click(continueCTA);
	}

	public void enterPassword(String password) {
		waitForElementToBeVisible(passWord);
		sendKeys(passWord, password);
	}

	public void clickSignInButton() {
		click(loginCTA);
	}

}
