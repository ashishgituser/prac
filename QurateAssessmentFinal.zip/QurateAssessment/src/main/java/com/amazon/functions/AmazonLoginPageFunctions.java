package com.amazon.functions;

import org.openqa.selenium.WebDriver;

import com.amazon.pageObjects.AmazonLoginPage;
import com.amazon.pageObjects.LoginPageObjects;

public class AmazonLoginPageFunctions extends LoginPageObjects{

	public AmazonLoginPageFunctions(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	
	public void enterUserName(String username) {
		userName.sendKeys(username);
	}
	
	public void clickContinueCTA() {
		continueCTA.click();
	}
	
	public void enterPassWord(String password) {
		passWord.sendKeys(password);
	}
	
	public void clickLoginCTA() {
		loginCTA.click();
	}
	
	
	
	

}
