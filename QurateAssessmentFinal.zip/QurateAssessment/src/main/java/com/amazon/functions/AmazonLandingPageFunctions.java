package com.amazon.functions;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.amazon.pageObjects.AmazonLandingPage;
import com.amazon.pageObjects.LandingPageObjects;

public class AmazonLandingPageFunctions extends LandingPageObjects {

	public AmazonLandingPageFunctions(WebDriver driver) {
		super(driver);
	}
	
	public void enterSearchText(String text) {
		searchBox.sendKeys(text);
	}
	
	public void pressEnter() {
		searchBox.sendKeys(Keys.ENTER);
	}
	
	public void scrollToParkAvenue() throws InterruptedException {
		//((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", searchText);
		//Thread.sleep(500); 
		
		Actions actions = new Actions(driver);
		actions.moveToElement(searchText);
		actions.perform();
	}
	
	public void clickParkAvenue() {
		image.click();
	}
	
	public void clickAddToCart() {
		addToCart.click();
	}
	
	public void hoverAccountsAndListsCTA() {
		Actions action= new Actions(driver);
		action.moveToElement(accountAndListsCTA1).perform();
	}

	public void clickSignInCTA() {
		signInCTA.click();
	}

	/*
	 * public void selectCurrency() { Select s = new Select(currency);
	 * s.selectByVisibleText("USD");
	 * 
	 * }
	 */

}
