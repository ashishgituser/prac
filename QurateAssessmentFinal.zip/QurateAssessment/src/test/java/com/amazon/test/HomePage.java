package com.amazon.test;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.logging.LogEntries;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.amazon.pageObjects.AmazonLandingPage;
import com.amazon.pageObjects.AmazonLoginPage;
import org.testng.Assert;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import java.util.*;

import resources.Base;
import utils.ExcelUtil;

public class HomePage extends Base {

	public static Logger log = LogManager.getLogger(Base.class.getName());

	@BeforeTest
	public void initialize() throws IOException {
		driver = initializeDriver();
		log.info("New driver instantiated");
	}

	// @Test(dataProvider = "getData")

	@Test(dataProvider = "Authentication")
	public void basePageNavigation(String Username, String Password) throws IOException {

		navigateToURL(prop.getProperty("url"));

		AmazonLandingPage amzFnctnObj = new AmazonLandingPage(driver);
		AmazonLoginPage amzLgnObj = new AmazonLoginPage(driver);

		String expectedTitle = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
		String actualTitle = driver.getTitle();
		log.info("Validating title....");
		Assert.assertEquals(actualTitle, expectedTitle);

		amzFnctnObj.hoverAccountsAndListsCTA();
		amzFnctnObj.clickSignInCTA();

		amzLgnObj.enterUsername(Username);
		amzLgnObj.clickContinueButton();
		amzLgnObj.enterPassword(Password);
		amzLgnObj.clickSignInButton();

		log.info(Username + " " + Password);

	}

	@AfterTest
	public void teardown() {

		driver.close();
		log.info("Browser closed");
		driver = null;

	}

	@DataProvider
	public Object[][] getData() {

		Object[][] data = new Object[2][2];

		data[0][0] = "anshu.sec22@gmail.com";
		data[0][1] = "123456";

		data[1][0] = "anshu.sec22@gmail.com";
		data[1][1] = "456788";

		return data;
	}

	@DataProvider
	public Object[][] Authentication() throws Exception {
		Object[][] testObjArray = ExcelUtil.getTableArray("src/test/resources/TestBook.xlsx", "Sheet1");
		return (testObjArray);

	}

}
