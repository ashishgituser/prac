package com.amazon.test;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.amazon.functions.AmazonLandingPageFunctions;
import com.amazon.pageObjects.AmazonLandingPage;

import resources.Base;

public class Search extends Base {

	public static Logger log = LogManager.getLogger(Base.class.getName());

	@BeforeTest
	public void initialize() throws IOException {
		driver = initializeDriver();
	}

	@Test(dataProvider = "getData")
	public void searchProduct(String text) throws IOException, InterruptedException {

		navigateToURL(prop.getProperty("url"));

		AmazonLandingPage amzPageObj = new AmazonLandingPage(driver);

		log.info("Entering search text......");
		amzPageObj.enterSearchText(text);

		amzPageObj.pressEnter();
		

		amzPageObj.scrollToSellOnAmazonAndClick();

		/*
		 * WebElement element = page.getSearchText(); Actions actions = new
		 * Actions(driver); ((JavascriptExecutor)
		 * driver).executeScript("arguments[0].scrollIntoView(true);", element);
		 * actions.moveToElement(element).perform(); actions.click(element).perform();
		 * Thread.sleep(500);
		 */

		// amzFnctn.scrollToParkAvenue();
		// amzFnctn.clickParkAvenue();

		/*
		 * Set<String> ids = driver.getWindowHandles(); Iterator<String> it =
		 * ids.iterator(); String parentId = it.next(); String childId = it.next();
		 * driver.switchTo().window(childId);
		 */

		// amzPageObj.clickAddToCart();

	}

	@AfterTest
	public void teardown() {

		driver.close();
		driver = null;

	}

	@DataProvider
	public Object[][] getData() {

		Object[][] data = new Object[1][1];

		data[0][0] = "watch";

		//data[1][0] = "headset";

		return data;
	}

}
