package com.amazon.test;

public class Assertions {
	
	//Assert.assertTrue(webDriver.findElement(By.xpath(launchPageHeading)).isDisplayed(),"Home Page heading is not displayed");	
	//Assert.assertTrue(webDriver.findElement(By.xpath(newCustomer)).isEnabled(),"New customer hyperlink is not displayed");	

}
